from setuptools import setup

setup(name='belashovplot',
      version='1.0',
      description='High level library to construct graphics with matplotlib',
      packages=['belashovplot'],
      author_email='Uclaptrap@gmail.com',
      zip_safe=False)
