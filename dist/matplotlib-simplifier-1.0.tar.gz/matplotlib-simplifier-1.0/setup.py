from setuptools import setup

setup(name='matplotlib-simplifier',
      version='1.0',
      description='High level library to construct graphics with matplotlib',
      packages=['matplotlib-simplifier'],
      author_email='Uclaptrap@gmail.com',
      zip_safe=False)
